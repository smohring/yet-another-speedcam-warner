INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2548300','51.6296900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9297200','53.0292200', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9130600','53.0363900', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1100800','48.4941400', '1');
INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2347500','50.6261900', '1');
INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9801700','50.4122500', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9973300','50.4095000', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5789400','51.4898100', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4932800','51.2596400', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5041100','51.2607200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5985000','49.8607500', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.1978900','49.3953900', '5');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6332500','53.0520800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7075000','51.4020000', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6908900','50.6473300', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6891100','50.6633300', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6908300','50.6502800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7511100','50.7025000', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7762200','50.7123600', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7226700','50.6876100', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6893300','50.6692800', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6665000','50.6277800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6833100','50.6390000', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6668100','50.6275000', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6592800','50.6199400', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1755600','47.7612500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7919400','47.8283300', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6555600','48.5533300', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.9007200','47.8293100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6095800','48.3364200', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.8466900','50.8805300', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5483300','51.0323100', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4632200','53.4361100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.2054400','53.2322800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4966700','53.6373900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4730800','52.6875000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8016100','51.9277200', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0738600','50.7770600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0738900','50.7776700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0890300','50.7821700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0693100','50.7620000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0959400','50.7744400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0997800','50.7594200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0398100','50.8364400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0476100','50.8318900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0534200','50.7991900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0755600','50.8058300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1856400','50.7131100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1812200','50.7046700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1009200','48.8292500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0669400','48.8350000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0709400','48.8278600', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0706900','48.8276700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0949400','48.8449400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2982200','48.8211400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1109400','48.8393300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0804400','48.8386100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0923600','48.8351400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1006700','48.8337800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1114400','48.8292500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0730800','48.8633600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0246400','48.8683300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1860300','48.8038300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1818900','48.8044400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1146900','48.8438300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0646700','48.8353600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0402200','48.8449400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0580600','48.8738900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0596400','48.8488900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1062800','48.8638900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1089400','48.8686100', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1051400','48.8617200', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8941400','48.9166400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9170800','52.1374400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9056700','52.1259700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5615600','51.2563300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8983900','51.7783300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9040600','51.7948100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8481900','51.7743100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9530300','51.7658100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2358100','48.6234700', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2713600','48.6273600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3893100','48.7488100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3725000','48.7612200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3835600','48.7601400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5638900','48.6900000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5688300','48.6963900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7128600','52.9498600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4868100','51.5631900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1682200','50.8741700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1990000','50.8871400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1947200','50.8606100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1798900','50.8793600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2351100','50.8528300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3497500','53.5127500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9480600','51.7389400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9552800','51.7396700', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4362500','52.0651100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2251400','48.5932800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2151100','48.5907200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9391100','50.2848100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0086100','52.0100800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0074200','52.0105600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8353300','53.7149700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9622800','48.5571400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8740600','48.5798900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3216900','51.5328100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3298900','51.5202500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0689200','51.3757800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1428300','51.3922200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9009400','51.4655800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1309200','49.9721400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1997800','51.3387800', '12');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6449200','51.7987200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1524200','48.9048100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1275000','48.9060300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1431900','48.9032800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9075000','51.1238300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9046900','51.1225300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8920300','51.1331400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8452200','51.1076900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9894700','51.1308900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4988900','48.9347200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.8491400','48.3742500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.9140800','48.3771100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.9201400','48.3803100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.9076900','48.3856900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.8806700','48.3858100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.8901400','48.3701100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9804400','50.9658900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4340300','48.9444700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4385800','48.9728900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1511100','52.3366700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0667800','52.3224400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0661100','52.3269400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2660000','50.2983100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7065600','48.5846400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6805800','48.5807200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0171100','51.7198900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5214200','48.0243300', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3299700','52.3280800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.0191100','52.7787500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5305800','51.8428600', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6073100','50.2198300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6418600','50.2231900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6717800','50.2239700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6817500','50.2215800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6855300','50.2274700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2208300','50.6366700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2441900','50.6463900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2159200','50.6552200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4287500','50.9310300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4177200','51.6157500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4345300','51.6095000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4801700','51.5920300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4856700','51.5905800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7311100','48.7702800', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7780600','49.4905600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3893900','52.3384700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7747200','52.2066700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8128100','52.2116700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8226700','52.2260300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1496700','52.1041100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7059400','52.0513300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6567500','52.0585000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1817800','51.5826700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.1692500','50.9144400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7293100','48.6940800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7323900','50.1724700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7336100','50.1745800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7356100','50.1727500', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7352800','50.1862500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7570000','50.2089400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7838100','50.1928100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7255600','50.1661100', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5145800','50.9836900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4075300','51.9411400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5703300','48.7753300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1735800','50.9082800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1881900','50.8990600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5331100','51.2754700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8643300','48.2698100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8364400','48.2550800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8775800','48.2474200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8446400','48.3001900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8331400','48.2354400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9030600','48.2470300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8525600','48.2382800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9210300','48.2533100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4500800','48.7576400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.9134400','49.9123300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.8886100','49.9018600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1294400','53.9186900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9821900','48.7515000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5492200','51.0049400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2080000','51.7647800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2686700','48.5705000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2601900','48.5746400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2697200','48.5746100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8603100','47.9890600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2375000','48.9480600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6226700','50.9527800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1572200','50.9940000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2026100','50.9950000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1325000','50.9885000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6434700','51.0268100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3148900','52.5120800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3768600','52.5020800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3865300','52.4901700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4093300','52.5168600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4447200','52.5453100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3100000','52.5679700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3755300','52.4553300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3166100','52.4643100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3189700','52.4540800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3358300','52.5421400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6002500','52.6883600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6838900','50.7877800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6819400','50.7897200', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3880600','48.5647200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3579200','51.5777800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7702800','48.0972200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7905600','48.0936100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7965800','48.1012500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7819400','48.1050000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7736100','48.1000000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7952800','48.0944400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8153600','48.0737800', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4104200','49.6854400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4070000','49.6846700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9819400','51.9872800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5744200','52.0418300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4811700','47.8184400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5405600','52.0303600', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5423300','52.0303600', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5289200','52.0298100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5333300','52.0321400', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5400000','52.0302500', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5346100','52.0319400', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5477200','51.2678900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5529200','52.0222200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5039400','51.9803900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5147200','51.9876900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4664700','51.9807800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6066400','51.9323900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5978600','51.9958900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6098100','51.9975000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5664400','52.0178900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5646100','52.0628300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5529200','52.0569400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5810000','51.9560600', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6244400','52.0554400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6238100','52.0553900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4630300','51.9693600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6385300','52.7408300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6381100','52.7400000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1318300','48.9571700', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1368300','48.9497200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1396400','48.9435800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1213100','48.9524400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1071100','48.9401400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0965000','48.9629700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0863900','48.9468900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0787800','48.9445300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6650800','48.7461700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.1975600','53.1928100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.1696100','51.1435600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7326100','50.3902500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7375800','50.4135000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8737200','48.4130000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8913100','48.4441100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8616400','48.4294400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9986400','51.9869400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6322800','52.6087200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2213300','51.5256700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0064700','48.6843600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0036100','48.6832800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0097800','48.6854400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0300000','48.6954200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0077200','48.6888100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7323300','48.7161100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0048600','48.6780000', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5728600','51.8475000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5675300','51.8624400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2213900','51.4606400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6892500','53.3755800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6098600','48.6376700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6228900','48.6390000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6129200','48.6335800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6111100','48.6475000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1516400','50.6879400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1486100','50.6911100', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1578900','50.6853100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1633300','50.6802200', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1526400','50.6955600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1484400','50.7470600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0570800','50.7357200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0579700','50.7041100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1813600','50.7414200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1791700','50.7481700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1140000','50.7108600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0878100','50.7398100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1684700','50.6866100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0988600','50.7221100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1069700','50.7209200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0678100','50.6748600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0577800','50.7480600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1021900','49.0401900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1211100','49.0406900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3440800','48.8694400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2505000','51.5736100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8517500','51.8245300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8082800','51.9677200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4033900','51.8513100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8140000','51.8168900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8135800','51.8159400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9300800','50.7757200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5592500','53.6983100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1700300','51.6989400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1791100','51.7006700', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5106900','52.4139400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5449700','52.4083900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5961900','52.3943100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5497200','51.7604700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6213900','51.7138100', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6150000','51.7134700', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7044400','50.5522500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4417500','51.2761700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4580600','51.3100800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8110300','53.0717200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8061100','53.0736100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8085800','53.0829200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9001700','53.1241100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8638300','53.0712500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3286400','51.7497200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7747200','50.0904400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8182200','53.0467200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7995300','53.0551700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0620300','52.2471900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8251700','53.0789700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8238300','53.0781900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8312800','53.0812200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7904200','53.0863900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8754700','53.0825000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8925300','53.0792800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8600600','50.0742500', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7850600','53.1021700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8316900','53.0811900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5911900','53.5814200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6152500','53.5822800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5881900','53.5360800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0192200','52.6079700', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.7161100','51.1350000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6306400','51.4610300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9221900','50.1828600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9293300','50.1804700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9271700','50.1733300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9318600','50.1948900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9276900','50.1879700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9112800','50.1970000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6476700','49.0869200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5900800','49.0788900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8861700','50.8122800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.2481700','53.6645600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0615300','52.2390800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0756400','52.2369200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1488100','50.7591900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5720000','51.5875800', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.1521700','51.8196900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4569700','49.6460300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4698100','49.6425000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4703900','49.6427200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4493100','49.6641100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4492500','49.6613300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4384400','49.6623600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3480000','51.2098600', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5011100','53.3592200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5429400','49.9256900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9417200','51.7434200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7397200','48.7160800', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7366700','48.7402800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7266700','48.7156700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3552800','51.5978300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3482200','51.5825300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3184200','51.5373300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3149400','51.5650000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0740300','52.6060300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0637500','52.6065300', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9263900','50.8338900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9410000','50.8267500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9081700','50.8331900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9016700','50.8320000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0005300','50.7773900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3355800','51.7489400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9248100','50.8453900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1762800','51.9281400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2411100','51.9396700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2421400','48.6794700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0896700','51.9040600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3260300','51.7432200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3370300','51.7354400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8616700','51.6412800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3190600','51.7216900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3243300','47.7340300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7035300','50.0997200', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7211100','52.9017800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7781400','52.8497200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6462800','49.8818900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6436400','49.8548600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6636400','49.8676100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6473600','49.8653100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6725000','49.3971700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6504200','49.8738300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6041700','51.7627800', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5756700','51.7629700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5686700','51.7609700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6069400','51.7627200', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6092800','53.0491900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6390800','53.0436100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6328300','53.0531900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6370600','53.0467200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3218900','48.6923900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.8290300','52.3960300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.1801400','51.8165600', '12');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.2428300','51.8353300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.2523300','51.8362500', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.2530300','51.8368100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.2497200','51.8191700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.1754700','51.8016100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.2443900','51.8408100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.2455300','51.8121700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.1467200','51.8037800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.2843300','51.8470800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1088300','48.6096700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7727800','50.0198600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7881700','50.0322800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7858300','50.0276900', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7855300','50.0273900', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2820000','50.7365000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3002800','50.7426900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3076400','50.7772800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2949200','50.7701900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3098900','50.7233100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0727200','48.8325600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0595800','48.8199400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9801400','48.8503300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.1383600','51.1213100', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.1391100','51.1212800', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3700000','52.5216100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4821400','47.9568100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4908300','47.9495300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4918900','47.9640800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5506700','47.9421400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8172500','48.6848900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8197800','48.7145300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3515300','52.9895300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9762200','51.6559400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9822200','51.6577800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4680000','51.5001900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4014200','51.4823100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4527800','51.4771400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5208600','51.5627200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3235800','51.5168100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3233300','51.5088900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3255000','51.4913900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4749700','51.5071400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4468900','51.5239700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5378900','51.5559200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6827200','48.5543100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6641100','50.0207200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7093900','50.0019200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7345300','49.9980300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7428900','49.9790000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6955000','50.0168100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6946900','50.0150300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6967200','50.0100800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7891400','51.7559700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8160600','51.0088600', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6777800','51.0584700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7581900','51.0525800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8509200','51.9114400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7358300','51.0878600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7156400','51.0303600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7942200','51.0013900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7933100','51.0020800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7421900','51.0423600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8074400','51.0271900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8082800','51.0526100', '14');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8302500','51.0620000', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2505600','51.5157200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3726900','51.8665300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2013100','51.8497500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4985000','48.2129400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4686400','50.8303100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5028900','50.7924400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5003100','50.7952200', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4888900','50.8134200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4655000','50.8289200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4944400','50.7632800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7915000','48.8554200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6426400','48.6428100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8603100','51.1681100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7904400','51.2073100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7822500','51.2156400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8029400','51.2384700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8311900','51.1927500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8400800','51.2275800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7749400','51.0295000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7390300','51.1983900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8098600','51.1757800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8101900','51.2559400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7510800','51.2650800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7508100','51.2004200', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1860800','48.8698600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5413300','48.7083100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5511400','48.7096900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5002500','48.6903100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5263100','48.7081900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6695300','50.4820300', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7022200','50.4691100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7084400','50.4656400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.6353900','52.1351900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.6166400','52.1540000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.6445800','52.1433100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.6534400','52.1417500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.6386900','52.1444200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.6020600','52.1506400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7337500','48.7062500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4235600','50.7744200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5926900','50.9253600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6009400','50.9358100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2320300','51.4580600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6606400','49.6956100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2414700','51.8591700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3161400','52.3837500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3154700','52.4425300', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4209700','50.9856100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5793100','52.1354400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3513900','51.2912200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4108300','51.3175000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0405800','51.8801700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8860800','48.3205000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8256400','50.7760800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7685300','50.7555800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0422500','50.9693900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0423600','50.9753900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0404400','50.9805600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3609200','51.0579200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4314700','48.5554400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9792500','50.1704200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9896700','50.1555800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2964400','52.3983100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3413300','51.6317500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3375800','50.8155300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3468600','50.8148300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3231900','50.7885300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2094400','52.5925300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2966700','50.8205800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2691400','50.8261700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3030600','51.6465800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9138600','52.4806400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2369400','50.7990800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1880800','51.2611100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6504400','52.3484700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5544200','52.3922200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9914700','51.3988900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9313900','51.4636100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0629700','51.4631400', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0698100','51.4643100', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0645600','51.4638900', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0753900','51.3796400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0185600','51.4693300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0070800','51.4336900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9785800','51.3814700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0169400','51.4550000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0248900','51.4171900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0599400','51.4384700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0063900','51.4446700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0281900','48.8150000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3403300','48.7332800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3313900','48.7296900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3048100','48.7354400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5797800','53.0142500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7623600','50.6760800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8846400','51.9415600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9058100','51.9262800', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8578100','51.9666100', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0947200','52.1048100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1049400','52.0853900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9256700','52.4933600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6006100','48.8414700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.1181700','47.5362500', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.1112500','47.5161100', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2595300','48.8311900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2533900','48.8270300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2718900','48.8203100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2690600','48.8249400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6430600','50.1170600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2170300','48.6761400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9663600','51.1763600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9842500','51.1652800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0082200','51.1782200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4354200','54.7707800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4235600','54.7715800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4394700','54.7827200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4378900','54.7813100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4349400','54.7798900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4373100','54.7867500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5741700','50.4253600', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5650600','50.4161700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4308600','50.0425800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4399400','50.0435600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6797800','50.1169400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6540800','50.1442200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6840300','50.1317500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7113900','50.0991900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7316700','50.1186100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7313900','50.1188900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6911900','50.0988300', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5313600','52.3552800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4728100','52.3720000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4485800','52.2815300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5202800','52.3797800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5401400','52.3446400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3711700','50.7031100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8046700','50.9171100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7612200','50.9349200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2087200','48.9396100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2034400','48.9351900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1984200','48.9257800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8612800','47.9886900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8531100','48.0131900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8447800','47.9901900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8543100','47.9911400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8446100','47.9901400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8326100','47.9937800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8576900','47.9958600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8451700','47.9908300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8692200','47.9885000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8472800','48.0260800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9086100','47.9858900', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8114700','48.0255800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8155800','47.9837800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8229200','48.0040300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8749200','47.9879400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8946400','47.9875300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8881900','47.9885000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8412500','47.9883900', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8414400','47.9886900', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9642500','51.5829700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1684200','54.3153100', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3527800','48.5922200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3731100','48.5765800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3336900','48.5786100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7466700','50.3280000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7919200','50.3543300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7856900','50.3479700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7187500','50.3291700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8007500','50.3268300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4553900','47.6572800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4814700','47.6586400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4683300','47.6566700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4822800','47.6536400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4052800','47.6700000', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3995600','47.6902800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3450000','50.9897200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3459700','50.9910300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5838300','52.7285800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7080000','51.4775300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6016700','47.8525000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6919400','50.5621400', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6926100','50.5599200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6624700','50.5659400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7083900','50.5529700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6861100','50.5630800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6819400','50.5607500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6078300','50.5403300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0059400','49.4815600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.9893600','49.4519200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5061700','51.6863900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6505000','48.6373300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5857200','51.1008300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5950000','51.0976400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0902500','50.9735000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1182800','50.9967500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1008300','50.9574200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1596400','50.9940800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8226900','48.6274700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8229700','48.6173600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8181100','48.6174400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7591900','48.5852800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8666900','48.6355800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8059700','48.5877200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9107200','48.6370000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0791700','51.5502200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0766700','51.5079200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1066900','51.5163100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0595000','51.5577200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0771900','51.5497200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0545800','51.5864700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0726700','51.5120800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0801400','51.5806700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0926900','51.5166900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0899200','51.5210800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0887800','51.5143600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1366900','51.5063600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0559400','48.8015000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0641400','48.7918100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4900000','49.7350300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9108600','50.4517200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9200000','50.4475600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9114700','50.4516400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8475600','50.4527800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0611700','51.2763100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9835600','51.9530300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8525000','48.2380000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9922800','48.3864200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2111100','51.6100300', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2264400','48.6148900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2380600','48.6269200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2792800','48.6282800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0235300','50.9218600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0195000','51.5434200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9993600','51.5761700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1316400','51.6887500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1563300','51.7173300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8830600','48.8604200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9195000','51.7037200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0830000','48.4514400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6663900','48.7252200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6166900','48.6696100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6176700','48.7050300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7220800','48.7433300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6684200','48.6856100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6837800','48.6882800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6281900','48.6892500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.0477800','51.8006100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.9797800','51.1390800', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.9753100','51.1493600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.9445000','51.1479700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.9840600','51.1260600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.9727200','51.1433300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9406900','51.5205300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9182200','51.5303100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9615800','51.5066900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9499200','51.5225000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7589200','48.2115800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7596900','48.2120600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3718300','51.3352800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4010000','54.0947500', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3984700','54.0947800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2318900','51.4635600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7716700','52.5594700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4215000','54.0782200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5881100','49.8641100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5886100','49.8641700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8122800','51.0306100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2141900','51.1772800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8847800','50.1277800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7832200','54.1240600', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0648100','52.1660600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7366100','52.4072200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4841100','52.6079700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6205300','53.2263100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.0048300','53.0173900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2992500','49.0040300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5435800','53.4253900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5415000','53.4266900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5567200','51.2958600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4813600','49.9185800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4801900','49.8984400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5183900','51.3290000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4801900','49.8808600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4829700','49.8747500', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9864400','50.0838600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9911900','50.0772800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9704200','50.0836900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.0200600','51.1526400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9410300','49.8725000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8895000','49.8755000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4548600','52.4001100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7431100','48.9361100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7261100','48.9200000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.7022500','51.9627500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.7021400','51.9627500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5351900','50.9761900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5533100','51.0003100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.1821700','53.8007200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.1614700','53.7924200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3407500','52.1857800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3718600','51.9139200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3434200','51.9522500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0172200','51.1877800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4143100','51.7438900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4668600','51.3731100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4603900','51.3800000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4702800','51.3816100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5291700','51.3105600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5179700','51.3272500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4538300','51.3816100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4820000','51.3477200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4900800','51.3440800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4147200','51.3448600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4276900','51.3408300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3840800','51.3399700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4800300','51.3922200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5725000','51.3475000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5448100','51.3533600', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5282500','51.3484400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4483300','51.3588900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5228100','51.3886100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3975000','51.3436100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4625000','51.3241700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4117500','51.3530600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3219700','47.6756400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3177800','47.6766700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9394700','50.0861100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9481700','50.0786900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9302200','50.0734700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6853100','52.1100000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9424700','50.9538900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.9837200','51.4725300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5158100','51.1975600', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5766700','51.1939700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5272500','51.1610300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9581400','53.5606400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9530300','53.5617500', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1923600','53.4955000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1615600','53.5163100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0847500','53.6246100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0675300','53.5823600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9416900','53.5726100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8696700','53.4716400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9595300','53.4700800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0258900','53.5570000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0557500','53.5913600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8302800','53.5752800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1245800','53.5708900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0018300','53.6618300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9466400','53.5937500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9699700','53.5988900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0721900','53.5702800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9559200','53.6114700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9563600','53.6112500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8720300','53.5711400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9807800','53.4230300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9867500','53.5477500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0248300','53.5302800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1023100','53.5799200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9965800','53.6020800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0118900','53.5997200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0152500','53.6001900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8152200','51.6831700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8252800','51.6722200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8091700','51.6906100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8491700','51.6711100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8423600','51.6886400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5986100','51.7113900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6833100','51.7152800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6827800','51.7541900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9087500','50.1493600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8692200','50.1471100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9148900','50.1005600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9310000','50.0955000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8901400','50.1752800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8949200','50.1791700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8976100','50.1235600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9059200','50.1040000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9580300','50.1199700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9432200','52.3914400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0522800','50.1769400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7266700','52.3661100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7230600','52.3584200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4876900','50.8161100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7819400','52.4247500', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.7303900','48.1425800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7359400','52.3991900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7628300','52.3951900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7338900','52.3845800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7268100','52.3811400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7380600','52.3818300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7366700','52.3768600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6941100','52.3528600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7591900','52.3485000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2021100','51.9642200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5174400','52.6814400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4194700','52.7018600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1769200','51.4103100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7334400','50.8236900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7331100','50.8153300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7213900','50.8366900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4427800','51.9399400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7176400','49.4144700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7010600','49.4083900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6950000','49.4068300', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6834700','49.4281700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6875800','49.3754200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6860000','49.3913300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6693600','49.4050800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6845800','49.4058900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1235000','48.7390300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1565000','48.6774400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1535600','48.6790800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2253900','49.1679400', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2247200','49.1566100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2186400','49.1345000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2299700','49.1631400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2175000','49.1241700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2212800','49.1463900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1486100','49.1927800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1825600','49.1406900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1794400','49.1640800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1077800','49.1861100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1691700','49.1225000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3406100','53.1391100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9819400','51.3318900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9504200','51.3086100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6496400','48.6567500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6396100','48.6604400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6531400','48.6575300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0819400','51.0690000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7470000','51.3495300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6533900','49.5924400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3554200','50.7407800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3157500','50.7874400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3348900','50.7673600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3409200','50.7672200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1773300','48.5670800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4341400','51.4085000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6453300','52.0645000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6491700','52.1305000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7331700','52.1589200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7005600','52.1216900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7053600','52.1470800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2553900','48.5941400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8729400','48.6009700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8483300','48.5955600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8758100','48.5927800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8860600','48.5977800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8568300','48.6075600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8597500','48.6051900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8396400','48.5805300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8458600','48.6099200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8420600','48.6150300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8387500','48.6113100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8330300','48.6257500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8359200','48.6213100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7262200','51.1825300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1513600','51.5775300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3341700','51.6550000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2529400','51.6986400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7819400','52.2826700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2400800','51.8792200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0870300','50.8651400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1173600','50.8705300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9236100','48.7947200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9390800','48.7945300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9380600','48.7975000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9758100','48.7971900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2718300','52.3354400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2703300','52.3351700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7835600','50.0479400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7933600','50.0531400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8058900','50.0539700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8545800','50.0458300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8525300','50.0463100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3557200','51.0928300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3561900','51.0934700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8264200','51.2513600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7130000','53.1437200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9487500','51.1766700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3621900','51.3425800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5493100','51.9088600', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9419400','52.1548600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9617800','52.1498100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9542800','52.1501400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9644700','52.1653100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7869400','52.3807800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8836100','48.4055300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8926100','48.4139700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4700600','48.6930000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4587500','48.6909400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4615800','48.6945000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5458600','49.3186900', '15');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5835600','48.7991900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4677200','51.7615300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6941700','50.8058300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3818600','52.3689400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9375800','51.8829400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5702500','53.5073300', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2947800','52.0775000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3120000','52.0719200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4316400','51.8296700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2648300','51.4369700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2575000','51.4388300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.1405000','51.4325800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2772200','51.4238300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2793600','51.4215800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2039400','51.0546400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3076400','51.1618100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6355800','52.2654400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7525000','50.6874400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7574200','51.6012800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8086400','51.6147500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3853600','50.7150300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6518600','47.6026100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8883300','50.8959700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8514200','50.9010300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1006100','48.8891100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0982800','48.8952800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4102200','53.4426100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4123900','53.4425800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0203600','48.3211100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9995800','48.3405600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0004400','48.3325300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9940600','48.3380800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9124400','48.9533100', '12');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4340800','48.7441400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4394400','48.7586100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4377200','48.7716700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4094400','48.7750000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6681900','51.3687500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7075300','51.3396400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6277800','51.3677200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0858100','47.6794400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1494400','52.3391700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9661900','53.7027500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9679200','53.7034400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.9844400','51.4856900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1537500','51.0020600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7747800','48.5760000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5964700','51.1944700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7195600','49.4377500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7802800','49.4433100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7308300','49.4320800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3278100','51.7431700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5245000','51.5260300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2013900','49.0541700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7734400','50.2417800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7788100','50.2194700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7419400','50.2308300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7527200','50.2535600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7531400','50.2538600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7223300','50.2418100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5579400','49.5370000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5033900','48.8629700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5100000','48.8704700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7718900','54.1152500', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5129400','48.9161400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4997200','48.9059200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5055000','48.9200300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5299400','48.9395300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5345600','48.9472500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4742800','48.8993100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4708900','48.2236900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3654700','49.0046700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4010800','48.9894200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3843100','48.9914400', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4047200','48.9902500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5294200','48.9107800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3450800','49.0013900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3485300','49.0043600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3651400','48.9944700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3537200','48.9981700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3928900','49.0054700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4147200','49.0076400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3525800','49.0134400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4563600','49.0019700', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4418300','50.1397800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4423100','50.1396900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4523100','50.1492800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4165300','51.3661700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3245300','47.7343300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4195000','51.4436400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4357200','51.4321400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6996100','50.8724400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6965300','50.8672800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6266700','50.8513600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7160000','50.8993900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7183300','50.9118300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2451700','51.5543600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1225600','54.3199700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0642800','48.3076700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5957500','51.1291400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5690300','51.1521700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5162800','50.6403100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1422200','48.5278900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1447800','49.0381400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1438900','49.0469400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4630300','48.6546900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4613300','48.6504400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4644400','48.6419400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4595800','48.6380600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4172200','48.6542800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4082500','48.8887500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4930300','48.6371700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4908300','48.6380300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4135800','48.6440800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4818300','48.6157500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4111400','48.6614400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1054400','51.0888600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0000000','51.0381700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6514700','52.2034700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8901900','47.7841700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1558300','51.7811100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1462800','51.8040800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1637500','51.8049400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5879200','50.3648900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5961100','50.3252800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5880600','50.3595800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5482500','50.3683100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.8963900','51.2289700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2599700','51.7403300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9355300','50.9635300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0579400','50.9680300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9731700','50.9313900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9524700','50.9242200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8794200','50.9411400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0614700','50.9388900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9330300','50.9210300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9795600','50.9668100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9031900','51.0231900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9006900','51.0218100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9248600','50.9366100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9511700','50.9041900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3589400','48.6829200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1089700','48.7449200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9101900','51.2706900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2588600','50.6792200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1950800','50.6976900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2001700','50.6795800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1838100','47.6732800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2005000','47.6848100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1453300','47.6783600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1792800','47.6670800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1287500','47.7469400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1378100','47.6966900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6542200','52.2557500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1341100','48.8304700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0988600','48.8523100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2059700','48.8563100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2033300','48.8575800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2008100','48.8590000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3397800','53.6573300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0633300','51.7894400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.7068900','51.5216700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6172200','51.3413100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6925800','49.4071900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9732800','51.0014400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5210600','50.1820000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.1244700','53.5205800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1891100','53.4850600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7976900','48.6425000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.3841700','53.3266700', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2595800','51.0380600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2230600','51.0122200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2341700','51.0138900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2308300','51.0136100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2396100','51.0636700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2403600','51.0644400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1052500','48.4880300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8932800','48.3405000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8836100','48.3496900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9130600','48.3368300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9236400','48.3312200', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9326700','48.3265000', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4621700','49.6053300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4611100','49.5930600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4621400','49.6002200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4550600','49.6056400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4575600','49.6041400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4021900','49.6543600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5194400','49.6012500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5152500','49.6008600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3946400','49.6348900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3842500','49.6413300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6340300','54.3689400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1115300','49.1918600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.1448900','48.5363100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6871900','49.9843900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6658100','49.9870800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1166400','48.4882500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1240300','48.5041700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0610300','48.4822200', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0570600','48.4817500', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3203600','51.7879200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9461100','51.1216700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9775000','51.1398900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0336900','50.1765300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0411100','50.1825800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2233300','48.8598900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2188300','48.8560300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8731900','51.2457500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3531400','50.6759400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2554700','53.8705000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8730600','48.8480000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8816700','48.8486900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8790300','48.8508300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3860000','51.2959400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3735300','51.3178300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6083300','50.8795300', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6116700','50.8805000', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4174200','51.3108900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3679200','51.3146400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3961400','51.3057800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3925000','51.3730600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3900600','51.3616400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3615300','51.3634700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3800000','49.9937200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5530600','51.6954200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3943100','51.3461900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4058100','51.3317500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3955600','51.3322200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4057800','51.3514700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7750600','50.0170000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3670000','51.3254400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.8410000','51.3277800', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4262500','51.3517200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4124200','48.4641700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3226400','51.3750000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3766700','51.3445600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3774200','51.3488300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3824200','51.3406700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3708900','51.3611700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5741100','51.8475300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9010000','52.1646400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0681400','51.0938900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0614400','51.1506100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0121900','51.1374200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4765000','48.5458600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8886400','53.8713900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0146100','48.7983300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0021700','48.7915600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9927800','48.7995800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9917200','51.0161400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7076100','52.0859400', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0266700','51.0746900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9081100','51.0640300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9933300','51.0446900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9966100','51.0496700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9963100','51.0494400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0202500','51.0334400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0884400','51.0511100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0070300','51.0698300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0606900','51.0918600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9708300','51.0657500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9716700','51.0661100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0616700','51.0397200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0550000','51.0252800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6380600','50.7291700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4789200','48.7375600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4855000','48.7535800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2871700','51.9810000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4334400','52.3948100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.8117500','52.6183100', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6983300','48.7250000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5068100','54.4829400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.1288100','51.6049200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6744700','50.5361100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4301100','51.7540800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4329400','51.0336100', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9832500','52.9635800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3573100','52.4680000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3519400','52.5458600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2571400','50.9788600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3183600','50.9662500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1045000','51.6378900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3345600','51.7256700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3493300','51.6757500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.6746400','51.1039200', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.1767200','51.9856900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.9568900','51.3817200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2709700','50.8482200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2273300','50.8451100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2361100','50.9063600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7511700','52.2001700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7051100','52.2265300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7491400','52.1753100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4068900','51.3846100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8912800','48.5526400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6391700','48.7891700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6872800','53.8513600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6383300','53.8547200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7080000','53.8746700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7011900','53.8523300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6643300','53.8753100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6568100','53.8823300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4031400','53.7277200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5379400','51.7255000', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6050600','51.2046900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1627500','48.4703600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2420300','52.3520600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7461400','50.8989200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7551700','50.9220300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1762500','48.9047200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1945000','48.8877800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1945800','48.8845800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2082200','48.8894200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2145300','48.8887200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2018300','48.8893600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1886400','48.8890800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2235300','48.8875800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2048300','48.9030800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1991700','48.9025600', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2120600','48.9039400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1636400','48.8900800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1672200','48.9123100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2028300','48.9120300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1995800','48.9055600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2091400','48.8960000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6575000','51.0481900', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.1723100','53.6576100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8522500','50.1697200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8029400','50.1370600', '12');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8065800','50.1561100', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8448300','50.1375800', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8548300','50.1640300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2880000','50.0198100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4251900','53.4638100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0677800','53.8804400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5582800','49.4663100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5166100','49.4886400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5353900','49.4815800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4922200','49.5326900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6752800','52.4705000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4718900','49.4605000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4958300','49.4763300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4915300','49.4776900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4917500','49.4775800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4750000','49.4851100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4754400','49.4851400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4761400','49.4865000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4763300','49.4876700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4617200','49.4903900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4737800','49.4836900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5046100','49.4671700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4571900','49.5450300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4865800','49.5296900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5404400','49.4951400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5462500','49.4931900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2675300','48.9372500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2679200','48.9430600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.8915600','51.1473600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.8902500','51.1473600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0857200','48.8993100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0867500','48.9012200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0928900','48.8988600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0772800','51.6544200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1948600','51.6670800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1972800','51.6665600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9042800','51.4932500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9499400','51.1746700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6508900','50.6053600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4313100','48.6703100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6013600','47.7113300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5357500','52.3497800', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3083900','52.4532800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3104200','52.4512500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6320000','51.1165800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5273900','51.1300000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8258100','51.4641700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8470800','51.3893900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7703600','51.4672500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7546700','48.5090000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2871100','51.3391900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1633100','51.3205800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9750000','51.2480600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9989700','51.2319400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9947500','51.2605300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8478900','48.4914200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9886100','51.2888900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2880600','48.5354400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9663100','52.2773900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9635800','52.2698900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9677800','48.8225000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9616700','48.8230600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9622200','48.8183300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9647200','48.8175000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1366400','48.8880300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4319400','47.9677500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4336900','51.2135800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4420600','51.2065800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4308300','51.1479200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4437500','51.1871900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4437200','51.1825300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4890300','51.2003300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4461400','51.1754400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4475000','51.1708300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4216900','51.1626900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4100000','51.1957800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4127500','51.1160800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8880600','51.0861100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8886100','51.0850000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2602800','50.5298100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2593900','50.5950800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2190000','50.5666700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5750800','49.9818100', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5702800','49.9719400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5660600','49.9746700', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5514700','49.9800000', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5874700','49.9991900', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5781700','50.0125800', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6290000','51.1623900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1092200','48.3799200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4363100','50.9221100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8429400','48.9462500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8499700','48.9469700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8413900','48.9455800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8182200','50.1200600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8539700','50.1205300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8613900','50.1227800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8909400','48.8498600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8888100','48.8489400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5747500','48.1625000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5026100','48.1259400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5849200','48.1324200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6053300','48.1045000', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5880600','48.1352800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6306100','48.1281400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5664400','48.1405000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5368100','48.1002200', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6190000','51.9524700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6315000','51.9562200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6381100','51.9026400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7934700','48.8203600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7949400','48.8283300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6477800','50.4729200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7889700','48.8212800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6448100','51.3202500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7973600','50.3060000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8184400','50.2953100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2510000','48.6973900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2648600','48.7372500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4545000','49.9530800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4563100','49.9515800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4452500','49.9476400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2692500','48.6146700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2441700','48.5870300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0675800','48.4256900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7228600','50.6481900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.2939700','53.1817800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7357800','53.8071400', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5047200','50.2881900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4886900','50.3019400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5231900','50.3108600', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3518100','52.4105000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2662800','53.5594400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2666700','53.5593900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2669400','53.5600000', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2348900','53.5570000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2343300','53.5568100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2631700','53.5515300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3615800','51.5896400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2833300','48.6750000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5461100','51.4342200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4501900','52.9929400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0306100','50.7819700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3576900','50.8231900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6803100','51.2137500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6840300','51.1655600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6718100','51.1863100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4614400','52.8693300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5998900','53.3791900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0954400','53.3449700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9775300','50.4316100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0551400','50.4576400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0130800','50.4255800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8730600','50.2286100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8623100','50.2409200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8587800','50.2350300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9093300','50.2289700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9102500','50.2265300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8789400','50.2196100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8785800','50.2212800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5059700','51.1967200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8748900','50.8746100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0885000','50.8241900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1571400','51.2093900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7766100','48.9193300', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1520300','52.2888300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1596400','52.2906700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5785000','51.3125000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5857800','51.3093900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5586700','51.3225600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5550800','51.3261100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8033100','53.3776700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0729200','52.4406400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0715000','52.4285300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4540300','48.6742200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4583600','48.6681900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5759400','50.9247500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0700300','49.4548900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0975800','49.4500300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0625000','49.4408300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0550800','49.4448300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0588100','49.4432800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0400800','49.4542800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.8128300','53.1170000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8645000','51.4991700', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8619400','51.4932800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8569400','51.5175000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7619400','50.7908300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7584400','49.6227200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8587500','50.0750800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1182800','51.0348900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1656100','51.7933300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2549200','51.6561100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6161700','48.1488300', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6160800','48.1501700', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8075000','50.1140600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7510300','50.0910000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7835300','50.1054400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7816100','50.0943100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7936700','50.0961400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7458300','50.0845000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7740300','50.0838900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9312500','48.4968600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9482800','48.4402500', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9233600','48.5126700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9188100','48.4873100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0316100','48.4125000', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5320600','48.6480600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1930000','53.1435300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2224200','53.1318900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2193600','53.1242800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2224400','53.1317500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2187200','53.1391100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3813100','51.6981900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8261100','51.0392800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8415600','51.0339200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8584700','51.0516700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4904700','51.3484700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4723900','53.4830800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0583600','52.2703600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0530000','52.2672200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9915300','52.2960000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0349400','52.3014200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0355600','52.2999700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0364200','52.2915600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0409200','52.2724400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0570800','52.2683300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2668900','51.3863900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9562200','50.8519400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0617200','52.2483300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0055300','52.5817500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8607200','52.0365000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8429400','48.7289400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2750000','48.7139400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2318600','48.7240300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2891100','48.7150300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4068100','51.9411700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2776700','48.7254200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2539200','48.7364200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2555800','48.7245600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2435300','48.7327800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2655300','48.7055300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2582800','48.7096900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2718900','48.7093900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2536100','48.7063900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.1548600','51.2002500', '12');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3542500','54.2596900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7455800','48.7308100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8343900','51.1949700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2789200','50.9341900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2593100','50.9699200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2602800','50.9701900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4524400','48.5822200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6667800','51.7536700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8292500','52.1316100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3911400','48.7767500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.1917800','51.2349200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.8213900','53.4268100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9776100','53.5186700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9830800','53.4906900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.0130600','53.5155600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5968300','52.3640300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0775000','47.8025800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0589400','47.7888600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3959200','51.8632200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0546900','52.4301700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2503100','51.2310000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5320000','49.0090300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6646100','48.8877800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6793900','48.8901400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6945000','48.8921700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6951900','48.8908900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7071900','48.8965300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7206700','48.8966100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6649700','48.9009700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6721900','48.8990000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6557800','48.9040000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6640000','48.9010300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2090300','48.9595800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7918300','53.9117500', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8228600','51.2437800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4293300','48.7171900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.9715300','53.0313100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0706100','50.9205800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0827200','52.4111900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0949400','52.3704200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0788600','52.3805800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0017500','52.4055600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4206400','51.8828600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4152200','50.2101700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7780800','50.9571700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7922800','50.9805000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8215800','51.0225000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.0240600','51.1814700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.0208300','51.1978100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2376400','51.0990300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9452200','52.6822800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.8344400','53.0992500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9292500','51.1142200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9615000','47.7390800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9723100','47.7378100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9599200','47.7465300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9012200','51.8881400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2980300','52.1957500', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2159400','48.8631100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2100300','48.8589700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2247500','48.8669700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2039400','48.8507200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0411900','52.2722200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2036100','48.8682200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3310000','52.6205600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7473600','51.0513300', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8337500','51.3126400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2237500','52.1368900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9209200','51.2959400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5353600','50.0948900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8732200','51.2949400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6221100','47.7649200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6073900','47.7838100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5910300','47.7317200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6423100','48.7261700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2675300','51.6018100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4371900','51.7755300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.1140800','49.0090300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.0580600','49.0138900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.0988900','49.0281900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4575000','48.7132500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4641400','48.7147200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6633100','50.9871100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7444200','50.9406400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8338900','49.8286400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8335800','49.8333300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8267200','49.8421700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1575000','51.1740300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1844400','51.1827800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2824200','48.8882800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2745800','48.8694200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2743300','48.8700300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4166900','48.8210800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4238900','48.8151400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4106400','48.8175300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4483600','48.8091700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2138600','48.4946900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1855000','48.5415000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1884200','48.5041700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1718100','48.5018100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1403600','48.4438300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1345800','48.4514700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1718900','48.5220000', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1609200','48.4284400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1480600','48.4403300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2165300','48.4950000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2204400','48.4925800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2231700','48.4908900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2207800','48.4941400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2137200','48.4928600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2393600','48.5601100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2253300','48.5639700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2056400','48.5472200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2015000','48.5500000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1480800','48.4835300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1438900','48.4825000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2206900','48.4905300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2195600','48.5015000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2312500','48.5409700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2063300','48.5340800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1785800','48.5300300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1858100','48.5327800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2279200','48.5247500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2232800','48.5139400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2221700','48.5133600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2986700','51.8084200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2843300','51.8788900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3234400','51.8110800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7095800','51.8564700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9453600','50.6173100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9924700','50.6474700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5063300','52.2134200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5065800','52.2149400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9056100','53.0896100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4813600','51.4421700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4816400','51.4490300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4855600','51.4393900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5122800','54.2594700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1030300','52.2078300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8191700','49.9798300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8255600','49.9833300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7883300','49.9744400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8008300','49.9691700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7931400','49.9667500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7983300','49.9762500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8183300','49.9988900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8917200','50.0216100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8707800','50.0161400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8686900','50.0160000', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1780000','48.6658100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3145300','50.7872500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8557200','50.0006400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8456400','49.9881900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8885300','50.0507800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2087800','50.6352800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1890800','50.6621100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2349700','50.6261900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2056900','50.6781100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7124400','50.2984700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7101400','50.2972200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7048900','50.2697200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0251700','49.0209700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1269200','52.0090000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1455600','51.9807200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2174200','52.0146700', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2155300','52.0140300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0196900','53.6326400', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7686900','49.8630600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7511100','49.8507500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.1812200','54.1021700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.0688900','54.1519200', '12');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.0938600','54.0948300', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.1511700','54.0909400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.1225000','54.0752800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5343900','52.4219700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.9633100','51.3464400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9356700','48.4845300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9376700','48.4771100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9201700','48.4180300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9761700','48.4763100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9698100','48.4749700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8726700','48.5075800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9196400','48.4471900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9684200','48.5009700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9658300','48.5062800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6977200','48.1963600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6998900','48.1974200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4306400','50.8427800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4316100','49.9828600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4318300','49.9822800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4282200','49.9868100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4283300','49.9866700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4369700','49.9815300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4376400','49.9818100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4293600','49.9794700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4190000','49.9892200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4564400','51.5261900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4136900','51.4816400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0019700','52.8804700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9977500','49.2381900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9511700','49.2440800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9419700','49.2420800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0356400','49.2785800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9607500','49.2553100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6454200','52.1644400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7318300','48.6919400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7432500','48.6894400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2861900','47.7652500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1386900','53.2278300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5915600','51.6797500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5888100','51.6812800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2897500','54.3545800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5851900','51.2549200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5518300','51.2483600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9131900','48.8747200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3771700','48.3142200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8426100','51.6814700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7268100','51.7012200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0865300','51.8965800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3054400','48.2924200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3063900','48.8353300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3421900','51.5383900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7040000','48.6481900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5262200','48.6713100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6110600','51.9148300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0058100','48.2657800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8373600','50.2191400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8265300','50.2114200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5148900','52.4001100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7170800','52.4734700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9423100','51.0637800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4388300','52.6733900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1197500','48.8894400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8027800','48.8023100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2711100','51.6273600', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2113100','50.9177800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0583900','50.4746100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3423100','51.5384400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1958600','50.0526900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2042800','50.0358300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7652200','49.5876700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3068900','51.2951100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4280800','53.5967200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4378600','53.5982500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.3853600','53.6443600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4572200','53.5998900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5581400','51.4608600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5458300','51.4083300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6035800','51.4330800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0674200','48.8768100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2561100','51.2628300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6244400','52.6716700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2205300','50.7568100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9865800','50.0378600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9628300','50.0398900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9291900','50.0549700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9374400','50.0552800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5428600','51.6797200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4669400','51.6624700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4973900','51.8805600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4811700','51.9201100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8571100','51.8360000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.1452800','53.8984700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2283900','50.7912800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2289200','50.7919400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0123100','50.8617500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0281100','50.8520800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9783100','50.8386900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9769200','50.8853300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3831900','50.5766700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3340300','50.6059200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3260800','50.6070600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2671900','50.6305800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2781100','50.6323100', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8365000','47.7572500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0996400','51.5425000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4054200','51.6329200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2942200','48.5666100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2714700','51.3572800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2764200','51.3550800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2786100','51.3144400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2112500','51.3070800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4580000','53.5865000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6438300','47.6630800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5013600','53.6011700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5017200','53.6013300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1834200','52.3015300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1824200','52.3005300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8974200','51.9713900', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5958300','52.3955600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9712800','48.2896700', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.3383300','47.9966900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8071900','48.4486400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2779200','52.1783600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3970800','52.1002500', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4200800','52.1415600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3418100','52.0168600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4010800','51.9962200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0921700','51.8834700', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0569400','48.6932500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0779700','51.8352200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0815600','51.8433900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9813100','48.6713300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.9541700','51.4648600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1999200','50.7810000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2129200','50.7260800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2318300','50.7278900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2377500','50.7368900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2980000','50.7786900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2845000','50.7620300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1994400','50.7720600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1915800','50.7851900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2661400','50.7401700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2631700','50.7155300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2426400','51.4630600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2629700','51.4085000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.0163300','50.9197800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.0167800','50.9198100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1699400','48.8407200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1686900','48.8283300', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1717200','48.7672800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1850600','48.8066100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2050000','48.8162500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2373900','48.8071400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2264700','48.8051700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2574400','48.7600300', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1867200','48.7813900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1785800','48.7570600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1833100','48.7824200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1504200','48.7297800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1536400','48.7917500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2181400','48.7868900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1091100','48.7401400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1050000','48.7392800', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2497200','48.7712500', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6237800','48.3611400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6713300','48.3911700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5314700','50.1378300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9875000','51.3591700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7491700','48.6794200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7586100','48.6745000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8981900','50.7160600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4863900','51.1078900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2131900','50.1717800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7742200','52.0253300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6227500','53.7617800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6098600','52.0407500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2645000','51.7457200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4783600','51.3183600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4109400','49.9230300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4060600','49.9289700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3838100','49.9345600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3971900','49.8780600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.8484400','52.0866400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2602200','48.1313300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1660600','50.8220300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0480000','48.4992500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0508100','48.4999700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0037500','48.5018900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0673600','48.5111100', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9859200','48.5249400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9753300','48.5272500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1683300','52.6644400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2701700','51.6750800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2622500','51.6619200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5758300','48.7045300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5799400','48.7134200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5905600','48.7217200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2643600','47.7431900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5010300','51.3656700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9777800','48.3869400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9782500','48.3956400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9830600','48.3922200', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9772200','48.3991700', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9794200','48.4019200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6543600','51.5012500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8124400','51.5403100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7180800','48.8141700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3670000','48.9420800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3198300','48.9290800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0978900','51.3388100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0972200','51.3515000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0294400','51.3330600', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4143100','51.2369200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4723600','48.0288100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4776900','48.0797500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4765300','48.0776400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4500300','48.0299200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5437500','48.0664400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5221400','48.0631400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5238300','48.0627500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4603300','48.0553300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4503300','48.0571400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6923300','53.3251700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8550600','52.1876100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8623900','52.1671100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4101100','52.3465300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3352200','53.8771900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8251100','52.0216100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0562500','51.5553300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1740800','50.6396700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1100800','50.6496900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3355800','51.4119400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3417200','51.4167200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3553100','51.4033600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2619400','51.7303300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5084700','52.5611100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3025300','48.8311400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3524400','48.8236900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3153900','48.8851900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2975600','48.8523600', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3176400','48.8686700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3151700','48.8170000', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3187800','48.8292500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3140000','48.8390000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3222200','48.8318600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2986900','48.8211900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3090000','48.8351700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3193900','48.8452800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0285300','51.0769200', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0288300','51.0766900', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.7712500','51.2172200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8133300','48.7666900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5600000','52.3612500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5892200','52.3800800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4353300','51.6154400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3933300','51.6080600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3802200','51.6319400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4739400','52.7625800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1128900','51.4890300', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9087500','51.9477500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9766700','51.9340600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9265300','51.8654400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6811100','48.7576400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6901400','48.7630600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2731100','51.1356100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3132500','51.1305300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5683900','50.2969200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7558600','49.6256700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7583100','49.6229400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0007500','48.5551100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9954400','48.5502200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8783600','50.7092500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8771900','50.7088600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8323600','50.7358100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5314700','48.6138100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6685300','49.5600600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6554200','49.5494200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.6480000','51.5099700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7057800','48.1498100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8716900','50.9637500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8425300','50.9903100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8852800','50.9382800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8168300','50.9533300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3878900','48.6697200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3709700','48.6680600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7577500','51.2511400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7172500','51.2768100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7226100','51.2453300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3410600','52.5233100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5911100','52.8375000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2069400','51.0976100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2206700','51.1156700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7199400','50.1960800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4142500','48.6935300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7504200','51.2710600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4272500','52.0883900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5154400','51.7147200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6016900','51.7041900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6686100','52.3091100', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6545600','51.6574400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9655800','50.8096100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9407800','50.8320000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3192200','52.2508600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5968900','52.5786100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5017500','50.5511900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5001400','50.5633900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5059200','50.5509400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5000600','50.5678300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5018100','50.5608300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5020800','50.5638100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5168900','50.5412500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8683100','51.4695600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4886100','50.9753900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6152800','54.2824700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2163300','50.0624400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2314700','50.0744700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2268100','50.0778300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2364200','50.0800000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2451700','50.0793300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5861400','52.2342500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4166700','47.6692800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7162800','49.3001400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7158600','49.2977800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6993100','49.3001100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7015800','49.2921900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7021700','49.2903100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1650800','52.5076400', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1778100','52.5041400', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1254400','53.5265600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1131900','53.5282200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0932800','53.5286100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1351400','51.6292800', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5547800','51.2799700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0816400','50.8587500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0532500','50.8033300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6082500','50.8026100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3106100','53.3366700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4817800','51.2487800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5596700','51.1552500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1386100','48.7656100', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1480600','48.7673900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3540800','51.4058100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3254200','51.7425000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8331400','48.2353900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5022200','53.1694400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4627800','53.1598300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5013300','53.2044200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7762200','52.4282200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7967500','52.4277800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2865600','48.6597200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2987200','48.6504400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2771700','49.6782200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2735600','49.6074200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2992800','49.6409700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2792200','49.6319400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3186900','49.6323300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5822800','54.0087500', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0046400','47.8621700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2031700','51.2977800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1829700','51.2776400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1737200','51.2607800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1313900','51.1993900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1510300','51.2261900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1508300','51.2561100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1300000','51.2663600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1335300','51.2529700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1638600','51.2570800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1282800','51.2776900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5788100','48.3720000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1145300','51.2508300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1433300','51.2473600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1046400','51.2534700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2359700','51.2676700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2355800','51.2771400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2367200','51.2735300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2419400','51.2958900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1904700','51.2256400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1906700','51.2246400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2126700','51.2356700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.9721700','51.1641100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1820000','51.2655800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0739700','51.2281100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0843600','51.2334400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2185600','51.2783300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1308100','50.8091100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9608100','49.8012800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9165300','49.7944700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7508300','50.8080600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3734400','51.2137500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7402800','51.2940600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0076400','52.2786400', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4488100','52.2526700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4589700','50.7069700', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2280600','51.4244200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4528900','49.9870300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4546900','47.6575000', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1063300','51.2141700', '16');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0364400','52.4265300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7471100','50.8919400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1803100','48.6725000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3983900','51.8622800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4575000','49.9069400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8413300','48.8470600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3158900','52.4645300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6160000','52.9205800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8234200','48.8347500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8993900','53.3821700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5945300','52.4110800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5245800','50.1346100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7125300','48.4628900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6452800','50.4716700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0585800','52.2705300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9468300','51.2270300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.8465600','50.8800800', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6200800','48.2023900', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2668600','51.4379400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1291900','51.6084700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0618900','53.0604700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0731900','48.9020300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0681900','48.8631100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.8768100','53.0011400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3301400','48.6387500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.8176700','50.7178300', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8124200','47.9819200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6515000','50.9224400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0001100','51.3296900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5745600','49.6949200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1634700','47.6804700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0626100','53.5264200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4612200','49.5933300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1541900','49.0047800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5368600','48.2810800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4103600','54.4053600', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4188900','52.4608900', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4163900','52.4605600', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5442800','51.0299400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4608900','49.4998600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5750000','49.6493100', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2239400','52.1377200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7156400','48.4674700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6855000','51.0075000', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7413300','51.0464700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2583600','51.2286100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1973600','47.7528100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7887500','53.9104200', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2734200','51.4529700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9387800','51.5564700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0468900','52.3148600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1244700','50.7854700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9467200','51.0052200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1514700','47.7822200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7674200','49.5866100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1849700','52.3568300', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4204400','49.9879400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8026100','53.4650600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.0490000','51.2317200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8930300','48.4174400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8395800','48.2561100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3848600','48.7601700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9775300','52.7521900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8336400','51.6766900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7219700','51.8809400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5831700','48.1470800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7365300','52.8384200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4120300','48.4610600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3682800','51.8026900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7828600','52.8070600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6101400','47.8158900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3261900','50.8229400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9870600','52.8236700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3225800','48.8318900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7687200','52.3380300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9362200','51.8847500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5272800','48.9101100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3243600','47.7343300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8736100','52.7015000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8322200','51.7197200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7771900','48.9196700', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6469700','51.9638600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9663900','48.4004200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5231700','49.4746900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7502800','50.1122200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4160300','52.4776700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1216700','50.3927800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9786400','52.7532800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8392500','48.2560300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4826900','49.9311100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4672800','52.3721900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2006900','50.7131400', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4823900','51.9192500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3810300','52.3777200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4637800','50.7522200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3947500','53.5724700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5440300','52.3467200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3208600','50.9639200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1441100','50.7754700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8086400','53.0831900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5010000','50.7175000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5016700','50.7213900', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4649400','49.6442200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7944700','50.0310000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3658300','51.2088100', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4693300','51.1688300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4600000','51.1672500', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7267200','50.4895300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1637800','51.2456100', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9593600','50.7988600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0366900','48.4039700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3375000','52.6854400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6066700','50.8786700', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6044700','50.8775600', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5969200','51.8996900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1838900','50.6948300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6430800','52.0847500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9472200','48.5031700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8121900','52.1460800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9775600','48.4000300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5938100','50.5733900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8772200','48.2475600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8312500','49.4035800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9521400','52.1740300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9633300','48.8229400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3286100','51.7408100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8443600','47.9762500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7347200','52.1688900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1566700','47.7711900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5132800','50.7403900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2797200','51.6263900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4189700','47.9723600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4192800','47.9723900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7787200','50.0141700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2513900','51.5720300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3051400','48.7356100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1629400','50.3055600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0166100','48.8006400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6775600','53.2681700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5751700','52.4854700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4151400','48.9936100', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5686900','50.2677500', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6002500','48.1154400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2381700','51.2794200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2249200','53.3423900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3377800','53.2668100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3671700','48.3996700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1243600','52.1353300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6625000','47.6075800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1367500','50.7782500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2811100','51.2864700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9415800','52.1376900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1699700','52.3066700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4718600','51.4224400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4300000','52.4261100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2188900','51.3358100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4722800','51.3626100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4297200','48.9155600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9915000','52.7638100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9508300','52.7346100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9373100','52.7223600', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8642800','52.6936900', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8378100','53.0827200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5395600','51.7390300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2347200','51.9370800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7895600','53.3203100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2645000','50.8208300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9913300','52.7633300', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8443100','47.9901100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7031100','50.0433300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7125000','50.0521900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0700300','48.8641700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5619700','52.4409400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6645000','48.1215000', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5654200','52.4486700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4600000','47.9835300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4654700','49.6444400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5977500','48.2457800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2652500','51.4372500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1606400','51.7363100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3913600','50.5189700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1814700','48.5844700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5386900','51.7397500', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4577800','50.3911100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4404700','47.8954400', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9496900','50.2870800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7841700','53.5327800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7711700','53.0616400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7452200','53.0531100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5583100','49.0848900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2817500','52.4812800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6605800','50.9912500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6415800','49.3011900', '17');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3283300','51.5243900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7618600','50.6611900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2027200','50.7947200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2035600','50.7942800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5250000','53.0949200', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4852200','53.1385000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6092200','52.4979200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4566700','52.4787200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4676700','48.8969700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9175000','50.7967800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7190800','54.0400000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7164700','52.3491700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8906400','52.6366100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7937800','48.7282800', '12');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1673300','48.6819400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1387500','48.6968900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3336400','51.6590300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9674200','52.7436700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7290000','48.9671400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6147500','48.9601100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6486400','51.0596900', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2645600','51.5618600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6701100','51.0335300', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6949400','50.9806100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.8460800','51.3220600', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6945000','50.9815800', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2013900','50.6376700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7407800','51.0596100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1848600','50.7856100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3587800','51.2829700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4744200','48.0322500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7114400','50.0523600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4800600','49.6292200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9022200','53.0715000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5897800','50.5553300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3023900','48.3846900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9977500','48.6724400', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3717200','48.3998100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3724200','51.2086100', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4114400','48.4635600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2378100','50.8118100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0152200','52.5832200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9208300','51.1550000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0320300','50.9828300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3338300','51.2103900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3524200','51.2091400', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5955600','54.3694400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1801100','50.8044200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1859700','50.8021100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1082200','48.7962500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0333600','50.7368600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2239700','51.3555300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7172800','52.6325300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4019400','51.5150000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9397200','48.4380600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3006400','48.7175000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9017800','53.0715600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1292200','50.9901700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1205600','50.9901700', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1317200','50.9902500', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5263900','52.3693100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2811100','48.8170300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5870600','48.7663300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3887800','50.6161700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5075300','51.5039400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8802500','54.0704400', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6607800','48.4319200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6643100','51.6945800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0211700','52.2471700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6745600','48.5883900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4590600','47.6565800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5005800','49.7537500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4904700','49.7332200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7455600','51.2700000', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2366400','51.8445000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3334700','51.6595800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7327200','50.4127800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3962200','49.0054700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5057200','51.0779200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9834400','51.9616100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5698900','49.3805800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0334400','50.9671700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9491900','52.0532500', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9493100','52.0536400', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2038600','48.8616700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2077200','48.8624200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.9300600','53.4480000', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0393100','48.2681700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2925600','51.6740300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2821100','50.0127200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2408900','50.0667200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0509200','51.8797800', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7547200','48.2088100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7545000','48.2086100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0507200','51.8811100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1437800','49.9784700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4345800','50.8657500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8466400','53.0811700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6052200','50.7000800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4373100','54.0899400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4734400','54.0837500', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7194200','48.5329200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6764700','48.5423100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7695000','52.3659400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8405600','53.0410000', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5626900','49.6584400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1642500','48.7770300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3449200','51.2131900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5160300','53.7757800', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6636400','50.5662500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8066900','47.9882200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7423600','49.9789200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.9576900','51.2175600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4172800','54.0801400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6594400','49.6956100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4518600','52.3038100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6486900','52.1241100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7851100','53.1022800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7902500','53.0861100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8641100','53.0710300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9612800','48.8230600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4210300','54.0780800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9827200','50.1742200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7901900','53.3203100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9169200','48.5836700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3553100','52.0456100', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0566100','52.2683300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8798900','50.9558100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9261400','51.8664400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2567500','51.2682200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8297800','51.6780000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2952200','51.3981900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4506400','52.5225000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4348600','52.4405000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3309400','52.4909200', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3420000','52.5180300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3109200','52.5679700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4616700','49.6036100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5701700','53.5075600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5086900','48.8648100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5478900','51.0346700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2054200','48.8894700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4582800','53.5864400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0258600','48.8635600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8930000','51.9648300', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3543900','52.0460600', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4646900','48.7887800', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4188900','50.0202800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1330000','51.8667800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5372500','49.6777500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5372200','49.6779200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7621400','50.9929700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3992200','51.3285000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9174700','48.4991700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8744400','52.7023300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6522200','49.4116700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.9321100','52.5735000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4686900','52.6371900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9028100','48.3399700', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4131400','49.9800000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6706400','49.4079700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9155600','48.5811700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8334700','51.2880600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0312500','51.7748600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.1491700','53.1033900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9824700','50.1740600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2710600','53.1186100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9650300','51.5830000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3764400','51.3531400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1866700','48.7816700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5852200','51.6309700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3056700','48.7055600', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3059400','48.7054200', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7128600','53.1434700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3060000','48.7056700', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1591700','51.8819400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3712800','48.1358300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.9058900','52.5463900', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8015800','53.7836400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6818600','53.7076700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6909200','53.7915300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8758900','53.7725300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8300300','53.7030800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8500300','53.6516700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0620300','52.2487200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1614700','48.4694400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6525800','49.7140000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7245000','52.0767800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7216700','52.3786100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2264400','50.8503100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4733300','47.6577800', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9498300','50.8287500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8726900','50.0418600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3915000','50.4861900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4204200','50.6087800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3342500','50.3957800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3229700','50.6362500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3359700','51.3515800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2057800','48.5892200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7949400','52.9294700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7441900','52.3951400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7272200','52.3811400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9115000','51.0935600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2325800','48.6711900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6855800','50.8678900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3846900','52.7658100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3034400','51.3144400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6656400','50.4510600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5681700','50.4056900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0630300','53.5156900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5588100','49.6499700', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7505000','50.0914400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0483300','53.4841100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2793600','53.2591100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2253300','50.0727200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5371700','53.0002800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7808300','52.2827200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2168100','48.6765000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9497200','50.8280300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4338100','49.8601900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2268100','50.8504400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8262200','51.2512500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5688300','49.6406900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5062500','49.8168600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3674400','53.0895000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5584400','51.8881700', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5595000','51.8693300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9964700','53.4396700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6479200','52.4139700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2168900','48.6763600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2170800','48.6763600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0033600','51.0024200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9330800','50.9207200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5369400','47.7593300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.9529200','52.8916700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.9181900','52.9066700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6838900','51.3612500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1958600','48.8942200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4274400','49.4964200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4565600','53.0931400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5340000','53.2017200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3483300','51.3424700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6564200','51.0057800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4794700','49.7673900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1673300','52.5502200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2179700','52.6012200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2649200','51.9521100', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6560000','48.9039200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3935300','51.9041100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2324200','48.6710300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9940800','48.3841100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9539700','49.9668600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.6096900','51.7081400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6440600','49.6879400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6444700','49.6885000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5735600','49.7076400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1198900','51.0260800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8352800','48.5105600', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6950000','48.5311100', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3513100','52.5449200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4578900','49.4820800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2200000','53.3537800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4958600','51.2253100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9118100','48.6119400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5734700','52.0531400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9227800','48.4633300', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1165300','50.9663900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7372200','53.7881100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0625000','49.0106900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9941900','48.3868600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1506400','48.7302200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7863300','53.5334400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0015800','49.2419400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7073900','54.0375300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2022500','48.7932500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7961100','50.0306400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4019400','51.0545000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8036900','53.3762800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9315300','51.5574200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1430600','52.6761100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4561900','50.2811900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0074200','52.2785600', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4868600','49.8996400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4956900','51.2258900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8096900','50.5385600', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8378300','53.0827200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4306700','48.6713900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6851400','52.4687200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4728300','49.7153100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4818900','49.7201900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2854200','48.9628100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1223600','54.3201400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6669200','49.9866900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9163100','52.2730600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9125600','48.9531400', '12');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9198900','51.5552200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6793600','53.2692200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9502500','50.8549200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1585800','50.6766700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0531400','52.2673900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0533900','52.2672800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5954700','51.6730000', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8572200','50.0758300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8199700','50.9148300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1176100','52.0838900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8363300','47.7571700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9525000','50.9240000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4409400','50.8583100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8099200','50.5384400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6685000','52.1321700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7284700','48.7385600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1200300','48.8895000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3083300','51.3209700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7312500','48.7419400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.1598900','53.4661900', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2692200','48.8476400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5684700','52.4159700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4474200','50.2435000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4776400','52.3006900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0557200','52.4226100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0258300','53.3525800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1067800','51.2136700', '16');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4460000','48.2040300', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9767800','50.8853600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7119200','52.8375300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9246400','50.9364400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1306700','50.8310600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6183100','52.2944700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7733300','49.4703900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4814700','47.6583100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3869400','51.5464200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7276400','49.4065800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8283900','49.4056900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7523300','49.5110300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9397800','52.6893900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4215300','52.1424700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7927200','50.7156700', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4298600','52.4492800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8170300','50.6991900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8186100','50.6997200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1965000','48.9044700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1390000','52.3606900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4180600','48.1695000', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4198300','48.1706700', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1424700','48.9696400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7246700','51.7033600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5543100','51.2777500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9182500','48.4651900', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2114700','48.4817500', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4871700','53.4781400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9405600','49.8949400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9980600','48.3892800', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1163300','52.2145800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0861100','48.9467500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4560300','48.4455000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4579400','52.3882200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8047800','48.7978100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2079700','48.8985800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4033300','48.1588900', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4017500','48.1575800', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4642200','50.1912200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1300000','49.3185600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0660600','52.1929200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4254200','51.1686400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3125000','51.1455600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0731900','51.8551900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0617200','47.8566100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2952800','51.1069400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2390600','50.5524400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5319700','52.4227200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1097200','54.3138300', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5202800','50.6996400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2090300','53.3954200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2085600','53.3947800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1901700','53.3668300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5104400','48.8641400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9334400','47.7527500', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8147200','52.1550800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2784700','50.6581400', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3588100','51.7583300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.1307800','51.7659200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2025800','48.5365000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2708300','53.4179700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0949700','51.4695300', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.1470000','51.8225000', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9202200','50.7240800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4927500','48.0095000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2985800','50.7777800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4732200','47.9835600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2490300','50.9871400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2376400','52.2301400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1683300','49.3991700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5021400','50.5508600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6313300','52.9571700', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9335000','50.2672500', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3199700','48.7276100', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2127800','52.3384700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1838100','52.1064700', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0018100','47.7435300', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5681700','49.6428100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5666700','49.6544200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4932200','53.4601400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3252500','48.9284700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3255000','51.4916700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0924700','53.3623600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2878600','51.2501900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7251900','52.7306400', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7072200','52.1832800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2626900','50.8202200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8005600','51.1480600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9748300','52.8510600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6221700','49.6913100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6105000','49.6811400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5582800','51.3225000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6221700','49.6920300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9622800','53.0534700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9619400','53.0530600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8175000','52.9706100', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8171900','52.9726700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8563100','53.0434700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8559200','53.0557800', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9893900','52.8508100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2648900','48.8337800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2255800','49.1680800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8646400','51.5217800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4727200','47.9841100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0629700','52.1671100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8273100','51.4649700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8790300','53.0609200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5484700','51.1155600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2899200','51.2500800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7944200','48.7283300', '12');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5263600','52.4022200', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8079700','52.4891400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6488300','49.5571400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1259700','50.0505600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1195300','50.0550000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6093600','49.6811900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4481700','49.8582500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2150000','51.4239200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7753900','50.0059700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2157500','51.7546900', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5838900','52.4353600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7943600','50.4545600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7936100','50.4546400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3896400','52.4195300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6688900','52.4155300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4163100','52.4220600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4213900','52.4283900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4214400','52.4418900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4593300','52.4342500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4678300','52.4240300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5032200','47.9576400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5030800','47.9576700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2185000','50.7769200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7271100','52.9478100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5589700','49.6493600', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2028100','48.8669400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2441700','54.0813900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2861400','51.7115800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7313900','50.4102800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1920600','51.8289700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0052800','48.6910600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2208300','52.8883900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3404700','47.7011400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9760000','52.9147500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7681400','50.6793300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4057800','51.3380800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2116100','53.0126100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9383900','52.9751400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8924700','53.0792800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8336100','47.7565300', '15');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5968900','52.3641400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7690000','50.6795600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2416700','48.5608300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2751100','53.0133600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3910800','50.8127200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6486700','49.5568600', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5858100','48.4710000', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4183300','50.8062500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8123100','52.1459200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9910300','52.2960800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8414700','48.7871700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0947800','51.4696700', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9856100','52.3681400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0780000','52.5782200', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5020300','50.5509700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5023100','50.5639200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9980600','52.5872200', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9736100','52.6026400', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2400300','50.5570800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9196700','51.5551400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0779200','52.5784400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0576900','51.7438900', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3823600','51.6983100', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0297800','47.7731700', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9391900','50.8307500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2298600','48.6801700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8602500','48.8118300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9993100','48.3406900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8465800','53.7091100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8365000','50.5924200', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5302800','51.0511400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5321900','51.0574200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9392800','51.5562500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0560600','49.0060000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0785600','48.5121400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3118600','50.6271900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6700000','50.8058100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7098600','52.3874200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3938600','51.3514700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4923600','49.8298100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7031700','51.5843100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6024200','51.9620000', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7145000','48.3911700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7844400','51.8779400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5245800','52.8326400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3108300','50.6275600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4260300','51.7761100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4425600','53.2634200', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7524200','48.8101400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9417200','52.1377800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6916900','51.3606400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4294400','50.5320600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9473600','50.8690300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3572200','52.5533600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4869200','52.5125600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7281700','52.3743300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7319400','52.3693100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8410600','49.2745800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6784400','51.6081400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1138100','48.7047200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8217500','49.2978600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0982200','50.9633900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1291400','51.5925800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8280000','49.2433900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5600000','51.9175000', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7404700','48.4773600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3362800','51.6086700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.9579400','51.1958300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2821400','51.5406400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3919400','51.3462200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6146900','48.6641100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.1764400','51.9857200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7804200','50.0179200', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2138100','48.9052800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2316700','53.3398600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5322800','49.0094400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3596700','52.6033300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6077500','52.0411700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0705000','48.8276900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0672200','48.8347200', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6967200','50.0102200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4411100','51.9398900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1639200','47.6802800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6842200','51.3611900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7305000','50.6239200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6281400','52.9570600', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3193300','48.7264400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5005600','50.7161100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0787800','48.9446700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7913300','52.0104400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2716700','48.7094700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7305000','50.6241700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0673600','50.9522800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4910000','50.6603300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4305000','51.3514400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2276100','51.4245800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5602500','52.4167800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2441400','50.5552800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4057500','52.4066900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5749400','49.6493100', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7472200','51.2706400', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.7248900','48.3496100', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3792200','51.3041100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6247800','50.5993900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7813600','49.2474400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3754200','53.2981700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2509700','53.5324200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7502800','51.2709200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2127800','52.8338100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9154400','51.5355000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4123300','48.4611900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8681900','52.2425000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2711100','51.6274200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2570800','51.2282500', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2281700','50.0713100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6775000','51.2395000', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6738600','51.2651100', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6416700','51.2753300', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6646700','51.2702800', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0295000','52.2567500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4524700','49.6505000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9609700','51.7626900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4840000','52.6079700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0910800','48.4640800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9115800','49.2363100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5088100','47.9690300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1959400','51.2813900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.3993600','53.7176100', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8127200','47.9810600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9318100','51.7492800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6561400','47.6264400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9981100','47.7741700', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9758300','47.7893900', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5388100','53.3543300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1763300','53.1116900', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8586400','48.4531100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0126100','53.0835800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0268600','53.1066700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2990800','49.0037200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7333100','51.0467800', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9900000','51.5275000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5880300','52.6090600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9589400','48.2160000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8728300','52.9983100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0153900','50.9734200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1335300','48.4115000', '14');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7012500','52.7500000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1870000','48.7736400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6971100','50.1133900', '14');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5230300','52.5729700', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9901400','51.5275000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8274200','50.5903600', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5248900','52.4663600', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.1792500','52.5038100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3130600','52.3160600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1249700','50.4170300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8304200','47.9906100', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0317200','48.2553100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2090000','51.2828300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0185000','50.9486100', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0150800','48.3075000', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6980600','50.1131100', '14');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3267200','48.9814400', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8909400','52.5761900', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9259700','52.5498600', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4138900','51.3427500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0042500','50.9472200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0167500','50.9482200', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9681900','50.9584400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9852500','53.6493900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6133600','50.8039700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3563100','50.6730600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9436900','50.9538900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6852800','50.6583300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7191700','50.5725800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.6881900','50.5924700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8775000','51.1605800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7508900','52.3752500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9821400','50.9504200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7850000','53.1219400', '5');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1369200','51.9885300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7086400','53.8788600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7007200','53.8527800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2341100','51.9363100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9756900','50.9544700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4387500','51.1914400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2638100','51.3139700', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6617200','52.0575800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0406400','52.2719400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3036400','48.8211700', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4226900','50.8330600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7571100','53.4473100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6927200','53.4369400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5185300','53.6034400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7611400','53.5461100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4709200','53.5472200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3223600','53.5428300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3260600','53.7524200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3431700','51.6509700', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3235800','52.5035600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6440300','48.2508300', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9540600','53.3840300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6776900','51.6079200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4356900','51.2118100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8081400','52.3755800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6654400','51.1193100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9738900','50.1527800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8048100','47.9886700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7583100','51.0634200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0875800','48.8319700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0886100','48.8328900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5236700','51.0946400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5538600','51.9106900', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9028600','53.6999400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7872500','52.0483600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8765000','48.6397200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0673100','50.1357800', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6041400','50.0512800', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0790800','50.9494700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1588100','50.7236100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9955000','50.7801400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.9835600','51.4721900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.9334200','51.4808100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9525000','53.8977200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.9334200','51.4805800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.0173900','51.4978900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8558300','51.3100800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9911100','50.0213900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9031900','50.2255300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5733100','48.0039400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8101900','51.5401900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9224400','51.5427200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3407800','51.7713300', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4753900','52.4346900', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2129400','50.0414400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4293100','51.0668100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1506900','50.8414200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2503600','52.3065300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0745300','48.8203300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8023900','51.4322800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1432500','48.9728300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2350800','50.0721700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2540000','50.0602800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5598300','51.1198900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7489400','50.0919200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1166900','48.7996400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7222200','50.6877800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7511100','50.7020800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8622800','50.0877800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5625000','53.0741100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8612500','48.6544400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6631400','51.0954400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2538300','50.0603300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1379200','49.0431900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2813900','51.2864200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9442200','48.3869400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7562500','49.6161900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7563100','49.6258300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4891700','52.9952800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8588300','50.0748100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8802500','51.5256900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3852500','51.2727500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3854200','51.2726400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4328600','50.9854200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9372200','52.7222200', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5466100','50.2845000', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5267200','52.2694400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4062800','48.8430600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5469200','50.2843600', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0368300','52.0259400', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0210800','51.9660800', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0247800','51.8249700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0431700','51.9135800', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2397800','50.7829700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0049700','51.5552800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5374200','52.3358600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0554400','52.4225000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.8827500','50.7981900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9891900','51.1888900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0724200','52.4408100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0708300','52.4287500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0363300','52.4263900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1029200','50.4722200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2397800','50.7829200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2064400','51.2877800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1420800','51.2506700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1472200','51.2647200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0021700','52.2731900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9728100','52.1778100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4100000','48.8883300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5634700','52.1286900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2723300','50.8853900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4129700','49.9800000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4176900','54.0797800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5736100','49.6389400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5326900','50.0920000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2568300','50.0723900', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0626700','48.5608300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1761900','53.1116900', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8413900','47.9743600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3713300','51.3296400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4576900','50.7397800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5808900','48.1063600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2708600','50.8482200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4888600','52.8140600', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8651700','48.2697500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.1995600','52.6087500', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5650800','47.7018600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8363900','48.2550000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.3609700','51.0579700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6186100','52.4565300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7632800','47.8843300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7098100','53.8880000', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6398600','52.8616700', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4649400','52.7872200', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3441700','51.0620600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1416900','50.9940600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9222200','47.8035300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6524700','53.0388600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7818100','48.0919400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2406400','51.2666400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7257500','48.5614200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1478900','47.6897800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7200800','48.4918900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7505800','50.4638300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2826400','52.5337200', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4385300','53.2897800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1894200','50.6984400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7778300','51.2477500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3239700','48.8520300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7727800','50.0006100', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1661900','52.2928300', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1514700','50.9689700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2673100','51.2176700', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2655600','51.2174200', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4014700','51.9963900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5586100','49.3272800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0365300','51.0391700', '12');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4738600','51.3587200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5964700','50.9461900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4824400','52.3744400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.3978900','53.6288900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5509400','49.0823900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5023900','48.1928100', '12');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0032200','51.3311700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.7740300','53.5057500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2497500','48.4417800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2004700','48.8360300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8815600','51.4508600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5727800','52.4420800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5838100','51.6256400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3448300','52.4117500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9728100','47.7395600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1443600','48.7711400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1815600','48.7600000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1546900','48.5135800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2268100','48.8202800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3299400','48.5444700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2862800','47.9615000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2018300','47.9068300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2228100','48.8237800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2148600','48.8260300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2235300','48.8236100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6529400','51.0823300', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1163600','50.9523600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5663300','51.4703300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2768900','53.3861900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8345300','51.7201100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6400800','53.4483100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3689400','53.4636700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3796900','53.5943300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1768600','48.7567200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1817500','48.7593600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1535600','48.6386900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4603900','49.4954700', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4423600','52.3966400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4395300','52.4115800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7445600','51.2404700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7429200','51.2410000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6156100','51.9781900', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6130000','49.7270000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9664400','53.0577800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7133300','52.4958300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.2126400','51.2686100', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0393100','48.4199700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7168100','53.5333300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8720600','51.3502800', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8481900','51.2951700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8797500','51.3233900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9629700','53.0574400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5837500','52.4353300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2101700','52.2877800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.2293100','51.2866700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.1744400','52.2728600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1019400','48.4151700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1021900','48.4151100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7193600','50.3812200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.9741700','51.1550600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5434400','50.0824200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7976100','50.9383100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4552800','51.9837500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9638600','53.0574400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9001900','50.8431900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5970600','53.5746400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8335300','47.7260300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1086100','48.9432200', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1071700','48.9403600', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1085000','48.9432200', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1093900','48.9461100', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2189200','49.1343600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6137200','50.0342500', '14');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0567500','51.5553300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2876100','52.7471700', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7875000','52.3907200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1950000','49.2345800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0735600','48.9578900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1025300','52.3948300', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1023300','52.3950000', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2528900','48.4241400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1521100','50.7863100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1881700','48.5873900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8193100','53.0485000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1070300','48.9401400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8584200','51.9072200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2231900','50.0714400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4125000','53.2742500', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4750000','50.1773600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4569400','50.1870000', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4603300','50.1721100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5035600','50.1715000', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0430000','51.9135800', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7688900','49.4457200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7662800','49.4450800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7682800','49.4452200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0375300','50.1809400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5781900','52.3306700', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7380800','50.1848900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6156900','48.1452800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7906400','50.0847800', '14');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.9672500','51.2575600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7243100','47.9355300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9813600','50.9600000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.2885800','51.3233300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7322500','51.0792800', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4573100','50.2657500', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.1746400','52.2858300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7708900','51.2286100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7712500','51.2304200', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6950300','50.0151100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5059200','51.6866400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4570600','52.2014400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6339400','48.2949400', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5430600','49.6648600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5428900','49.6651400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1958600','48.7915600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4249400','52.4300800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4227500','52.4317200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5151100','52.4001100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2681400','51.6918600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0459400','50.1540600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.7235800','51.7013300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4234400','52.2575000', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8231900','51.6186900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1892200','51.2946100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1900600','51.2949200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6158300','48.1452800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6150000','48.1372200', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6152500','48.1361100', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7806900','53.5381100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4361100','49.6057500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0575800','50.4723900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4862500','51.1078900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9523300','50.9561900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.1991100','52.6083900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6903600','52.7249700', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6936900','52.7251700', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9628900','50.9591900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0938900','52.8183100', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0829200','52.8245000', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1034700','50.4712200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1685300','48.8283300', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8022200','53.4650600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1630600','49.2480300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.8836900','50.8170000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5216700','50.0813100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0096400','48.6920000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2192500','53.3555600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.8990600','50.8405300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5126400','52.0107500', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3633300','51.6111900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3630800','51.6116100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2960800','49.6225800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7727200','51.2576700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8895600','51.0706400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0052500','48.6781400', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6161100','48.1366700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6202800','48.1375000', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6158300','48.1363900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8188300','50.8220800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7271700','50.7011400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7464700','51.0573900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7463900','51.0575300', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7620800','51.2166700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.7611100','51.2147200', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9381400','50.7311900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9374700','50.7308100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0513900','51.4888900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7521100','48.4789200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9783900','50.9525000', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9842800','50.9483900', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.6728300','48.1374400', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6132200','54.5147800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6154400','51.3737200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7573100','49.3396400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6951900','48.8909700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0727500','48.4365600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7256900','50.7019200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9971700','48.4833300', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4061700','48.9779200', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2503600','52.3064200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5083100','52.2509200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2109700','51.6096400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4065300','53.0584700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2334200','51.0576400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8938900','53.4237200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1207200','53.7072500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.0956400','50.7710300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5230800','50.3106400', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4893100','50.3024400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7680000','48.7108300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3053600','49.0367500', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3046400','49.0366900', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4868100','52.8327500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3036400','49.0369700', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.8773600','53.0011700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.7986100','51.0660300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8121900','51.6864400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8120600','51.6865000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8403900','51.7156400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0420000','50.9519200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.7189200','48.1851700', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0965000','50.1105800', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2819700','51.6378900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4242200','52.4305300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8418600','49.6582800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4208900','51.8828900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3260000','51.3202800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2739400','52.6917200', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6478300','53.0365000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9915600','50.0100000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0706700','53.0715600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.1736400','52.9394400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.1802800','52.9144400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0660800','48.3047200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4152800','51.9203300', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1298600','51.4729400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1309700','54.3601400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1300300','54.3032200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5292800','52.3938100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9667200','48.5313100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9664200','48.5314200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9408300','51.5207500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9395800','51.5138900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3392800','50.2305600', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3587500','50.2183300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3434400','53.0030300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7768900','48.0378600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9689400','50.8713300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.3030600','50.9520000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3230600','51.3826400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1405800','51.1130600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4218100','50.1531700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4232500','50.1532500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.2455300','51.8120000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5060800','51.1967200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9468900','51.0052200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.7711400','51.2172200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2598600','51.7403300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4141900','51.7436100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.4893100','52.9953600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7507800','52.9364700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9440800','48.3869400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2677500','53.0643600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6187500','52.9187800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8731100','49.2139400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2266900','53.3536900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4591100','51.0331700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9893900','48.4086100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1498300','50.8414700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8684700','52.5841100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7563900','49.6163900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1462800','49.2914700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0788300','49.0896100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1506100','49.2277500', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1906900','49.0781100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9998100','49.0685000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.9728100','51.2185000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7593300','49.6289200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4121900','51.3146400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0111900','48.6720600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5006100','53.2704700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5736100','52.0532200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.1431400','52.6761100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1530600','48.5268900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1600000','47.7730600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4488900','50.2670300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.5106400','52.3229700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7886900','49.5439400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.3857500','52.4696100', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7887500','49.5440000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4144200','52.5535800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7518300','49.3477800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4467200','52.0161100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3053900','52.3998600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5702200','50.2662200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8104700','53.0720600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8111400','53.0720300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4811100','53.4604700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7054400','50.9400600', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6616700','52.3147200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1067500','50.9105800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5635300','48.0068600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4365600','52.4626100', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4413900','52.4628600', '18');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1522800','50.6880800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7878100','48.1009400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4346400','52.4621100', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9145300','50.9484400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4202800','52.4615000', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1576700','50.6852200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9022200','50.5430600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9372200','52.7954700', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0366700','50.4702800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6912500','53.8515300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2084700','48.8893100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1107800','48.4176100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.7492800','48.1573600', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9545000','50.8070800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.9545300','50.8068300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6398100','49.3129700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4593300','50.7069700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.0476900','51.8006100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4794400','49.6101900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.0069700','51.1983100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6857800','53.8510600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6845600','53.8511100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7076400','53.8566700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6970800','53.8515300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.5162500','50.6401700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.0588900','47.8129200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6076100','49.7261100', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5560000','47.6688300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3961400','52.9676900', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3883100','52.9678900', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.0088900','47.8208300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3225800','51.1789200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3786100','51.3204400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1757200','52.9811100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5573600','52.3598100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7800600','51.7031400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7703100','48.6973900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3025000','52.6747200', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3022800','52.6744400', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7501400','52.0628900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2732800','52.6918100', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.5478100','52.4965300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1982500','48.7931100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.3413300','51.0152800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.1863900','53.1425000', '14');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3372800','50.2368300', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1894700','51.4760600', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6186100','53.0630600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6052200','51.2580300', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.2391700','51.8533300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3408900','52.5231400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2591100','51.5020000', '12');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8935800','51.1848600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8043900','51.8664400', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8118900','51.8666700', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.2888900','50.9583300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8943900','51.1854200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0063100','48.2657500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4238900','52.4309200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3602800','49.0081900', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7087800','47.9346100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2345800','51.2755600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7734200','48.0233300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2693900','53.5647200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2949200','51.1081100', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6934400','49.3430600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4029700','52.4634700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0151400','48.7810600', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0097200','48.7829700', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1166700','48.9554200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3024400','48.7363900', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2679200','48.7434200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2678900','48.7436100', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2347200','51.2754400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8751400','52.7029700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0503100','50.3244200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1841400','51.2785800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5228600','49.4734200', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.2995300','50.7172200', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6145800','48.6638900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0344400','50.3408300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9540000','49.9669700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4259700','51.1686900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.9540600','51.0181400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9269400','52.2752800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1622500','47.6665300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9776700','52.7460000', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.4466100','53.8101100', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0354200','50.3409400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1012500','51.5102500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1672200','48.9121100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9863300','48.8520800', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5916400','49.5440600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5822800','49.5316700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3021400','48.7362200', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.0773900','51.0476700', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0525000','48.2916700', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7631100','52.1877200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.2304200','52.4032200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1018900','51.5097200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6695300','50.4819400', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.1840000','51.2786100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6794700','48.5810600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2595800','50.0706900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1623900','47.6667500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8047800','51.0195300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0939200','50.0376900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0991700','51.0785300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3373600','51.3750300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2747200','50.7318300', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3436400','53.0030000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.2819400','50.7172200', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9269400','50.8960000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5836700','49.1488900', '11');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.9746700','50.8583600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2766700','50.6905600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5382500','53.0472200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.5380600','53.0469700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5129700','52.0110800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6950000','50.5525000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6420600','52.3690600', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1028900','48.4766900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.3129700','51.7315600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.4461100','48.2042500', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7150000','50.9566700', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0932800','53.5287500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7069400','50.9436700', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7187500','50.9628100', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0681700','53.0891700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5750000','49.1536100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8504200','51.4310600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.5980000','50.8041700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.2550000','51.6950000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8001100','50.5789400', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.7169400','51.1348600', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8807800','51.5256700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7190800','48.0692800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9575000','48.6941700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7190800','48.0691900', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7216100','52.3273600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.5855600','51.4883300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8517200','48.4490000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9975600','48.4833100', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.0743900','51.8553600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.5558300','52.3626700', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0601400','48.8286900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7383300','53.4688300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2448900','51.4485000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9193100','49.2192500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4046700','48.9681100', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4092500','47.6700000', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7723300','50.0009400', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7338900','50.9827800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.1631900','53.9040300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.8010000','53.2770800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9353900','52.7925800', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.8985800','50.8211400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.8738600','50.8568600', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0609400','51.2761900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4166700','47.6693900', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4092500','47.6701400', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7807800','50.0176900', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3453600','50.6196700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3536100','50.6166700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7798900','50.1052200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6668900','50.7050000', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7506900','49.4444400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1263600','48.8487200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1261100','48.8488900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0226100','50.0263900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4399200','50.6314700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4771400','50.6072200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4758300','49.3395800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.7257500','54.0322500', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8271400','51.6674200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4758300','49.3394400', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0216700','50.0261100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.1365300','54.0924200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3236900','52.5035600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4129700','51.3750000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.3263900','52.3384700', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.7102800','52.3080600', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6302800','49.8156100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4528100','48.0220000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.0970800','50.4233300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6978100','52.3768100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9669400','50.5923600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0177800','48.9972200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.6709200','51.0876900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8965300','49.8358600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4676400','49.7993900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8202800','48.5115600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8228600','48.5212500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8224700','48.5021400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6893100','49.3570800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.6525000','50.8108300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.2138900','51.1773600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0362800','48.2059200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0365000','48.2057500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7686100','49.9990300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.8049200','50.8935800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.8026900','50.8988300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.4666700','51.5701400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.8002200','52.8340800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.0649200','53.5503300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7895000','53.0573600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8672200','48.5993300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8772200','48.6016700', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.3993900','49.6339200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1374700','48.4795300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3164400','48.8169200', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5340600','50.1146700', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5338300','50.1148900', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9805600','50.5450600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.8464200','50.8800800', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6385300','50.5848600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8214700','51.6690600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6121700','50.5919400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6345300','50.5796400', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6365800','50.5878100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.7542200','48.1512800', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0396100','53.0528900', '3');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8260000','48.5148600', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8385800','51.6540600', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3472500','49.1786900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6814400','51.5357200', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1663100','49.3770300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8292500','51.6735000', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.8893900','51.4378600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.3001100','53.2751100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.0098100','48.4898100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8769400','52.2798300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.4714200','50.8126400', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2225600','49.1245800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.4738100','50.6762500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4464400','51.3434200', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8550800','52.5669400', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.8440600','52.5643600', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6885300','50.2688600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2466900','49.0552500', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3940300','51.3390000', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.3569700','52.3228100', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '14.6094700','51.6060600', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3944400','51.3390300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4499200','51.3815000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4279400','51.3818100', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.4285600','51.3821100', '10');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.1677500','50.8736900', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7745300','48.5758600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.2029200','54.3313300', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5750800','49.9816400', '8');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.8064200','50.0539700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6653900','48.9008100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2041400','48.8616700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2062500','48.8561400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8752200','47.9878300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8949400','47.9873100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.2662200','50.2980000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '10.6878100','53.8512500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6686400','49.5597500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5517800','49.9800800', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5787800','50.0125000', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2535600','48.8268600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2036900','48.8572500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2011100','48.8587500', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.8453100','51.7021900', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1294400','47.7471700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9182800','51.5299700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7097500','50.0015600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7350600','49.9980800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6538900','49.5924400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2205300','50.7568100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2209700','50.7570300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '6.2351900','50.8525600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.3509400','52.5446700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.5878100','48.1350000', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '11.0657800','49.4476400', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9636100','48.8228100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '7.6381700','51.9023600', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6549400','49.5494700', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1631900','48.8901100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5878600','49.9993100', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.4151700','49.0077800', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6638300','50.0209200', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6955000','50.0166100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.6138100','50.0341400', '14');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9398300','51.5140300', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1827200','49.2313300', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.6023100','53.3890000', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7647200','47.6738900', '4');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.5801400','49.3885800', '13');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7265000','50.9060300', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2491100','53.8242500', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7341900','50.9020800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.9672500','50.5922500', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '12.7922500','52.6195800', '1');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.1520000','53.8205300', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '8.7046400','50.9249700', '2');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '13.6161700','52.4468100', '6');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.2145000','49.0991900', '9');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.9670300','52.1830600', '7');

INSERT INTO `d0140c6c`.`Blitzer` (`ID` ,`Latitude` ,`Longitude` ,`TypID`)VALUES (NULL , '9.4468600','51.3433900', '9');